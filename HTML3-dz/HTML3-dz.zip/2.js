function printName(a){
    console.log(`Привет, ${a}`);
}

printName(prompt("Введите имя"));